**1. How did you approach the data pre-processing, data cleaning and data normalization? Attach the Queries used here.** [10 marks]

**2. How did you approach the problem statement? Explain briefly** [5 Marks]

**3.a. Give an example of similar data available on a larger scale and your recommended Hadoop architecture to maintain the data.** 
**3.b. What is your recommended maintenance activity for the architecture mentioned above** [5 Marks]


